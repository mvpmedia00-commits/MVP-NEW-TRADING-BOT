"""
API package for trading bot
"""

from .server import app, set_bot_instance

__all__ = ['app', 'set_bot_instance']

"""
Examples Package

Example trading strategies demonstrating best practices.
"""

__all__ = [
    'RSIBollingerBands',
    'MACDEMATrend'
]

"""
API routes package
"""

from . import monitoring

__all__ = ['monitoring']

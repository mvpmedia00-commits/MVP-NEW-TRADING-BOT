"""
Main FastAPI application server for the trading bot.
Provides RESTful API endpoints with authentication, error handling, and monitoring.
"""

import os
import logging
from datetime import datetime
from typing import Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status, HTTPException, Depends, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.security import APIKeyHeader
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from api.models.schemas import ErrorResponse, HealthCheck
from api.routes import portfolio, trades, strategies, control
from api import dashboard_api

# Import bot
import sys
import threading
from pathlib import Path

# Add parent directory to path for bot imports
bot_dir = Path(__file__).parent.parent
sys.path.insert(0, str(bot_dir))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# API Key configuration
API_KEY_NAME = "X-API-Key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=True)

# Load API key from environment
VALID_API_KEY = os.getenv("API_KEY", "your-secret-api-key-change-this")

# Warn if using default API key
if VALID_API_KEY == "your-secret-api-key-change-this":
    logger.warning(
        "Using default API key! Set the API_KEY environment variable for production use."
    )


async def verify_api_key(api_key: str = Security(api_key_header)) -> str:
    """
    Verify API key from request header.
    
    Args:
        api_key: API key from request header
        
    Returns:
        API key if valid
        
    Raises:
        HTTPException: If API key is invalid
    """
    if api_key != VALID_API_KEY:
        logger.warning(f"Invalid API key attempt: {api_key[:10]}...")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key"
        )
    return api_key


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.
    Handles startup and shutdown events.
    """
    # Startup
    logger.info("Starting Trading Bot API server...")
    logger.info(f"API Version: {app.version}")
    logger.info(f"Environment: {os.getenv('ENVIRONMENT', 'development')}")
    
    # Initialize and start the bot
    bot_instance = None
    bot_thread = None
    
    try:
        from bot.main import TradingBot
        
        # Create bot (mode is read from config/global.json)
        logger.info("Initializing trading bot...")
        bot_instance = TradingBot()
        bot_instance.initialize()
        
        # Set bot instance in dashboard API
        dashboard_api.set_bot_instance(bot_instance)
        logger.info("Bot instance set in dashboard API")
        
        # Start bot in background thread
        def run_bot():
            try:
                bot_instance.start()
            except Exception as e:
                logger.error(f"Bot error: {e}", exc_info=True)
        
        bot_thread = threading.Thread(target=run_bot, daemon=True)
        bot_thread.start()
        logger.info("Trading bot started in background thread")
        
    except Exception as e:
        logger.error(f"Failed to initialize bot: {e}", exc_info=True)
    
    yield
    
    # Shutdown
    logger.info("Shutting down Trading Bot API server...")
    if bot_instance:
        try:
            logger.info("Stopping trading bot...")
            bot_instance.stop()
        except Exception as e:
            logger.error(f"Error stopping bot: {e}", exc_info=True)


# Create FastAPI application
app = FastAPI(
    title="Trading Bot API",
    description="RESTful API for managing and monitoring the trading bot",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# Configure CORS
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests and responses."""
    start_time = datetime.utcnow()
    
    # Log request
    logger.info(f"Request: {request.method} {request.url.path}")
    
    # Process request
    response = await call_next(request)
    
    # Log response
    duration = (datetime.utcnow() - start_time).total_seconds()
    logger.info(
        f"Response: {request.method} {request.url.path} "
        f"Status: {response.status_code} Duration: {duration:.3f}s"
    )
    
    return response


# Exception handlers
@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """Handle HTTP exceptions."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "HTTPException",
            "message": exc.detail,
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle request validation errors."""
    errors = []
    for error in exc.errors():
        errors.append({
            "field": ".".join(str(x) for x in error["loc"]),
            "message": error["msg"],
            "code": error["type"]
        })
    
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "error": "ValidationError",
            "message": "Invalid request parameters",
            "details": errors,
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "InternalServerError",
            "message": "An unexpected error occurred",
            "timestamp": datetime.utcnow().isoformat()
        }
    )


# Health check endpoint
@app.get(
    "/health",
    response_model=HealthCheck,
    tags=["Health"],
    summary="Health check",
    description="Check the health status of the API and its services"
)
async def health_check():
    """
    Health check endpoint.
    Returns the current status of the API and connected services.
    """
    return HealthCheck(
        status="healthy",
        version=app.version,
        timestamp=datetime.utcnow(),
        services={
            "api": "healthy",
            "database": "healthy",  # TODO: Implement actual health checks
            "broker": "healthy",
            "bot": "running"
        }
    )


# Root endpoint
@app.get(
    "/",
    tags=["Root"],
    summary="API root",
    description="Get API information"
)
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Trading Bot API",
        "version": app.version,
        "description": "RESTful API for managing and monitoring the trading bot",
        "documentation": "/docs",
        "health": "/health"
    }


# Include routers with API key authentication
app.include_router(
    portfolio.router,
    prefix="/api/v1",
    tags=["Portfolio"],
    dependencies=[Depends(verify_api_key)]
)

app.include_router(
    trades.router,
    prefix="/api/v1",
    tags=["Trades"],
    dependencies=[Depends(verify_api_key)]
)

app.include_router(
    strategies.router,
    prefix="/api/v1",
    tags=["Strategies"],
    dependencies=[Depends(verify_api_key)]
)

app.include_router(
    control.router,
    prefix="/api/v1",
    tags=["Control"],
    dependencies=[Depends(verify_api_key)]
)

# Include dashboard router (no API key required for dashboard)
app.include_router(
    dashboard_api.router,
    tags=["Dashboard"]
)


# Serve static files (dashboard HTML, CSS, JS)
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


# Dashboard route - serve index.html
@app.get("/dashboard")
async def serve_dashboard():
    """Serve the trading bot dashboard."""
    dashboard_html = os.path.join(static_dir, "index.html")
    if os.path.exists(dashboard_html):
        return FileResponse(dashboard_html)
    else:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Dashboard not found"
        )


if __name__ == "__main__":
    import uvicorn
    
    # Configuration
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    reload = os.getenv("API_RELOAD", "false").lower() == "true"
    
    logger.info(f"Starting server on {host}:{port}")
    
    uvicorn.run(
        "api.server:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info"
    )

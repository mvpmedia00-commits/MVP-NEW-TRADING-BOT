"""
SIFI Indicator Layer
Calculates arrows, ADR, Line of Scrimmage, X signals, pullback levels.
This layer produces signals but NEVER makes trade decisions.
"""

from datetime import datetime, time
from typing import Dict, Optional
from zoneinfo import ZoneInfo

import pandas as pd
import numpy as np

from ..utils.logger import get_logger

logger = get_logger(__name__)

__all__ = ['SIFIIndicatorEngine']


class SIFIIndicatorEngine:
    """
    Calculates SIFI-required indicators from raw OHLCV data.
    
    Outputs:
    - arrow_color: str ("red", "green", "gold", "purple")
    - line_of_scrimmage: float (5 PM EST daily open)
    - adr: float (Average Daily Range)
    - daily_high: float
    - daily_low: float
    - pb1_level: float (Yellow line - first pullback)
    - pb2_level: float (Light blue - second pullback)
    - x_signal: bool (X pattern detected)
    - candle_reversal_confirmed: bool
    - x_against_position: bool
    """

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.timezone = ZoneInfo(self.config.get("timezone", "US/Eastern"))
        self.adr_lookback = int(self.config.get("adr_lookback", 14))
        self.ema_fast = int(self.config.get("ema_fast", 20))
        self.ema_slow = int(self.config.get("ema_slow", 50))
        logger.info("SIFIIndicatorEngine initialized")

    def enrich(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Enrich OHLCV DataFrame with SIFI indicators.
        
        Args:
            df: DataFrame with columns [timestamp, open, high, low, close, volume]
            
        Returns:
            Enriched DataFrame with SIFI columns added
        """
        if df.empty:
            return df

        enriched = df.copy()

        # Ensure timestamp is datetime
        if "timestamp" in enriched.columns:
            enriched["timestamp"] = pd.to_datetime(enriched["timestamp"], unit="ms", utc=True)

        # Calculate daily metrics
        enriched = self._calculate_daily_metrics(enriched)

        # Calculate EMAs for directional bias
        enriched = self._calculate_emas(enriched)

        # Calculate arrow color
        enriched = self._calculate_arrow_color(enriched)

        # Calculate pullback levels
        enriched = self._calculate_pullback_levels(enriched)

        # Detect X signals
        enriched = self._detect_x_signals(enriched)

        # Log latest values for debugging
        if len(enriched) > 0:
            latest = enriched.iloc[-1]
            logger.info(
                f"SIFI Enrichment Complete - "
                f"Arrow: {latest.get('arrow_color', 'N/A')}, "
                f"ADR: {latest.get('adr', 0):.2f}, "
                f"X Signal: {latest.get('x_signal', False)}, "
                f"Range Position: {latest.get('range_position', 0):.2%}"
            )

        return enriched

    def _calculate_daily_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate ADR, daily high/low, line of scrimmage."""
        df = df.copy()

        # Line of Scrimmage: 5 PM EST daily open
        if "timestamp" in df.columns:
            df["est_time"] = df["timestamp"].dt.tz_convert(self.timezone)
            df["trading_day"] = df["est_time"].apply(self._get_trading_day)
        else:
            df["trading_day"] = 0

        # Daily high/low per trading day
        df["daily_high"] = df.groupby("trading_day")["high"].transform("max")
        df["daily_low"] = df.groupby("trading_day")["low"].transform("min")

        # Line of Scrimmage: open at 5 PM EST (first candle of trading day)
        df["line_of_scrimmage"] = df.groupby("trading_day")["open"].transform("first")

        # ADR: Average Daily Range over lookback period
        daily_ranges = df.groupby("trading_day").apply(
            lambda g: g["high"].max() - g["low"].min()
        )
        df["adr"] = daily_ranges.rolling(self.adr_lookback, min_periods=1).mean().reindex(df.index, method="ffill").values

        # Fill NaN with reasonable defaults
        df["adr"] = df["adr"].fillna(df["close"] * 0.02)  # Default 2% if no history
        df["line_of_scrimmage"] = df["line_of_scrimmage"].fillna(df["open"])

        return df

    def _get_trading_day(self, ts: pd.Timestamp) -> str:
        """
        Get trading day identifier.
        Trading day starts at 5 PM EST and ends at 5 PM next day.
        """
        hour = ts.hour
        if hour < 17:  # Before 5 PM
            # Part of previous day's session
            return (ts - pd.Timedelta(days=1)).strftime("%Y-%m-%d")
        return ts.strftime("%Y-%m-%d")

    def _calculate_emas(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate EMAs for directional bias."""
        df = df.copy()
        df["ema_fast"] = df["close"].ewm(span=self.ema_fast, adjust=False).mean()
        df["ema_slow"] = df["close"].ewm(span=self.ema_slow, adjust=False).mean()
        df["ema_slope"] = df["ema_fast"].diff()
        return df

    def _calculate_arrow_color(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate arrow color based on price position and momentum.
        
        Logic:
        - GOLD: Bottom 25% of range + upward slope
        - PURPLE: Top 75% of range + downward slope
        - GREEN: Mid-range + upward slope
        - RED: Mid-range + downward slope
        """
        df = df.copy()

        # Calculate range position
        range_size = df["daily_high"] - df["daily_low"]
        range_size = range_size.replace(0, np.nan).fillna(df["close"] * 0.01)  # Prevent division by zero
        df["range_position"] = (df["close"] - df["daily_low"]) / range_size
        df["range_position"] = df["range_position"].clip(0, 1)

        # Directional bias
        bullish = df["ema_slope"] > 0
        bearish = df["ema_slope"] < 0

        # Assign arrow colors
        df["arrow_color"] = "red"  # Default

        # GOLD: Bottom 25% + bullish
        gold_condition = (df["range_position"] <= 0.25) & bullish
        df.loc[gold_condition, "arrow_color"] = "gold"

        # PURPLE: Top 75% + bearish
        purple_condition = (df["range_position"] >= 0.75) & bearish
        df.loc[purple_condition, "arrow_color"] = "purple"

        # GREEN: Mid-range + bullish
        green_condition = (df["range_position"] > 0.25) & (df["range_position"] < 0.75) & bullish
        df.loc[green_condition, "arrow_color"] = "green"

        # RED: Mid-range + bearish (already default)
        red_condition = (df["range_position"] > 0.25) & (df["range_position"] < 0.75) & bearish
        df.loc[red_condition, "arrow_color"] = "red"

        return df

    def _calculate_pullback_levels(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate pullback levels for pending order placement.
        
        PB1 (Yellow): 38.2% Fibonacci retracement from recent swing
        PB2 (Light Blue): 50% Fibonacci retracement
        """
        df = df.copy()

        # Calculate recent swing high/low (last 20 candles)
        lookback = 20
        df["swing_high"] = df["high"].rolling(lookback, min_periods=1).max()
        df["swing_low"] = df["low"].rolling(lookback, min_periods=1).min()

        swing_range = df["swing_high"] - df["swing_low"]

        # PB1: 38.2% pullback from high
        df["pb1_level"] = df["swing_high"] - (swing_range * 0.382)

        # PB2: 50% pullback from high
        df["pb2_level"] = df["swing_high"] - (swing_range * 0.50)

        return df

    def _detect_x_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Detect X signals (reversal patterns).
        
        X signal criteria:
        - Price crosses EMA with strong momentum
        - Candle closes beyond EMA by at least 0.5% of price
        - Volume spike (>1.5x average)
        """
        df = df.copy()

        # Initialize X columns
        df["x_signal"] = False
        df["candle_reversal_confirmed"] = False
        df["x_against_position"] = False  # Will be set by strategy based on position

        # Detect crosses
        df["price_above_ema"] = df["close"] > df["ema_fast"]
        df["prev_price_above_ema"] = df["price_above_ema"].shift(1)

        # Bullish X: crossed above EMA
        bullish_cross = (~df["prev_price_above_ema"]) & df["price_above_ema"]

        # Bearish X: crossed below EMA
        bearish_cross = df["prev_price_above_ema"] & (~df["price_above_ema"])

        # Strength filter: close must be >0.5% beyond EMA
        strength_threshold = 0.005
        strong_bullish = (df["close"] - df["ema_fast"]) / df["ema_fast"] > strength_threshold
        strong_bearish = (df["ema_fast"] - df["close"]) / df["ema_fast"] > strength_threshold

        # Volume spike filter
        avg_volume = df["volume"].rolling(20, min_periods=1).mean()
        volume_spike = df["volume"] > (avg_volume * 1.5)

        # X signal = cross + strength + volume
        df["x_signal"] = ((bullish_cross & strong_bullish) | (bearish_cross & strong_bearish)) & volume_spike

        # Candle reversal confirmed: X signal + next candle confirms direction
        df["candle_reversal_confirmed"] = df["x_signal"].shift(1).fillna(False) & (
            (df["close"] > df["open"]) | (df["close"] < df["open"])
        )

        return df

    def get_latest_signals(self, df: pd.DataFrame) -> Dict:
        """
        Get latest signal values as a dictionary.
        
        Returns:
            Dictionary with current signal values
        """
        if df.empty:
            return {}

        latest = df.iloc[-1]
        
        return {
            "arrow_color": latest.get("arrow_color", "red"),
            "line_of_scrimmage": float(latest.get("line_of_scrimmage", 0)),
            "adr": float(latest.get("adr", 0)),
            "daily_high": float(latest.get("daily_high", 0)),
            "daily_low": float(latest.get("daily_low", 0)),
            "pb1_level": float(latest.get("pb1_level", 0)),
            "pb2_level": float(latest.get("pb2_level", 0)),
            "x_signal": bool(latest.get("x_signal", False)),
            "candle_reversal_confirmed": bool(latest.get("candle_reversal_confirmed", False)),
            "range_position": float(latest.get("range_position", 0.5)),
        }

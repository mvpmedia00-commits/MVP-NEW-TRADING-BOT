#!/usr/bin/env python3
"""
Test Crypto.com credentials to verify they're valid and properly configured
"""
import os
import sys
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

def test_credentials():
    """Test Crypto.com API credentials"""
    
    api_key = os.getenv('CRYPTOCOM_API_KEY')
    api_secret = os.getenv('CRYPTOCOM_API_SECRET')
    testnet = os.getenv('CRYPTOCOM_TESTNET', 'true').lower() == 'true'
    
    print("=" * 60)
    print("CRYPTO.COM CREDENTIALS TEST")
    print("=" * 60)
    print(f"API Key loaded: {'✓' if api_key else '✗'} {api_key[:10] + '...' if api_key else 'NOT SET'}")
    print(f"API Secret loaded: {'✓' if api_secret else '✗'} {api_secret[:10] + '...' if api_secret else 'NOT SET'}")
    print(f"Testnet mode: {testnet}")
    print("-" * 60)
    
    if not api_key or not api_secret:
        print("❌ ERROR: Missing API credentials in environment variables!")
        print("\nMake sure .env file exists in the project root with:")
        print("  CRYPTOCOM_API_KEY=your_key_here")
        print("  CRYPTOCOM_API_SECRET=your_secret_here")
        print("  CRYPTOCOM_TESTNET=true")
        return False
    
    try:
        import ccxt
        print(f"CCXT version: {ccxt.__version__}")
        print("-" * 60)
        
        # Try to connect
        print("\n📡 Attempting to connect to Crypto.com...")
        exchange = ccxt.cryptocom({
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True,
            'timeout': 10000,
        })
        
        if testnet:
            exchange.set_sandbox_mode(True)
            print("✓ Using sandbox mode")
        
        # Load markets
        print("📊 Loading market data...")
        exchange.load_markets()
        print(f"✓ Loaded {len(exchange.symbols)} trading pairs")
        
        # Check for our test symbols
        test_symbols = ['BTC/USDT', 'ETH/USDT', 'XRP/USDT']
        print("\nChecking required trading pairs:")
        for symbol in test_symbols:
            if symbol in exchange.symbols:
                print(f"  ✓ {symbol}")
            else:
                print(f"  ✗ {symbol} NOT AVAILABLE")
        
        # Try to fetch balance (this is where auth is tested)
        print("\n🔐 Testing authentication (fetching balance)...")
        balance = exchange.fetch_balance()
        print("✓ Authentication successful!")
        print(f"\nAccount Balance Summary:")
        print(f"  Total currencies: {len([c for c in balance['total'] if balance['total'][c] > 0])}")
        
        if balance['total']:
            for currency in sorted(balance['total'].keys()):
                if balance['total'][currency] > 0:
                    print(f"    {currency}: {balance['total'][currency]}")
        else:
            print("    (no assets in account)")
        
        print("\n" + "=" * 60)
        print("✓✓✓ ALL TESTS PASSED! Credentials are valid! ✓✓✓")
        print("=" * 60)
        return True
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\nTroubleshooting:")
        print("1. Verify API key exists on Crypto.com Exchange")
        print("2. Check if IP whitelist is configured:")
        print("   - Get IP: curl -s ifconfig.me")
        print("   - Whitelist at: https://crypto.com/exchange/user/settings/api-keys")
        print("3. Verify permissions are enabled on the API key")
        print("4. If using testnet, ensure you created testnet credentials")
        print("=" * 60)
        return False

if __name__ == '__main__':
    success = test_credentials()
    sys.exit(0 if success else 1)
